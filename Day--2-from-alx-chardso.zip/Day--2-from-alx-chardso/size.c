#include <stdio.h>
/**
* main - Gateway of all programming syllabus

* return(0):0
*/
int main(viod)
{
     char alxchar
     int mysuspension_from_alx
     long int corhotint
     float nofloat

     printf("size of char:%1d byte(s)\n", sizeof(alxchar));
     printf("size of an int:%1d byte(s)/n", sizeof(mysuspension_from_alx));
     printf("size of long int:%1d byte(s)\n",sizeof(corhot));
     printf("size of float:%1d byte(s)\n", sizeof(nofloat));

     return (0);
}





























