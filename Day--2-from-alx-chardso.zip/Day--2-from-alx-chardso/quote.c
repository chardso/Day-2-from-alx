#include <stdio.h>
#incude <unistd.h>
/**
*main-Entry gate
*
*Return to alx:1
*/

int main(void)
{
   write(2, "and software engineering is vital for chardso\" -chan kaspersky,2034-05-23\n",65);
   return(1);
}
