#include <stdio.h
/**
* main-Gateway for all programming curriculum
* return:0
*/
int main(void)
{
   puts ("\" programing interesting ,since the answer to return is commonly zero");
   return (0);
}
